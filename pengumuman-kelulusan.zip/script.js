
const dataKelulusan = {
  "3098983573": { nama: "AHMAD ADI SETIAWAN", status: "LULUS" },
  "0105365084": { nama: "AHMAD ALVINO PRADANA", status: "LULUS" },
  "3102607165": { nama: "AHMAD NAJI", status: "LULUS" },
  "0091784494": { nama: "AHMAD NAUFAL ARIFUDIN", status: "LULUS" },
  "0108332606": { nama: "AHMAD QIQI WARDANA", status: "MASIH ADA KEKURANGAN ADMINISTRASI" },
  // (tambahkan semua data lainnya)
};

const countdownDate = new Date("June 2, 2025 16:00:00").getTime();
const countdownEl = document.getElementById("countdown");
const statusEl = document.getElementById("status");
const loginEl = document.getElementById("login");

const x = setInterval(function() {
  const now = new Date().getTime();
  const distance = countdownDate - now;
  
  const days = Math.floor(distance / (1000 * 60 * 60 * 24));
  const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((distance % (1000 * 60)) / 1000);
  
  countdownEl.innerHTML = days + " hari " + hours + " jam "
  + minutes + " menit " + seconds + " detik ";
  
  if (distance < 0) {
    clearInterval(x);
    countdownEl.innerHTML = "";
    statusEl.innerHTML = "<strong>Pengumuman Kelulusan Kelas IX SMP Ma'arif Bandongan Tahun Ajaran 2024/2025</strong>";
    loginEl.style.display = "block";
  }
}, 1000);

function cekKelulusan() {
  const nisn = document.getElementById("nisn").value;
  const hasilEl = document.getElementById("hasil");
  const hasilStatusEl = document.getElementById("hasil-status");
  const keteranganEl = document.getElementById("keterangan");
  const kataMutiaraEl = document.getElementById("kata-mutiara");

  if (dataKelulusan[nisn]) {
    const data = dataKelulusan[nisn];
    hasilEl.style.display = "block";
    hasilStatusEl.innerHTML = "<strong>" + data.nama + "</strong><br>Status: <strong>" + data.status + "</strong>";

    if (data.status === "LULUS") {
      keteranganEl.innerHTML = "Selamat atas kelulusanmu!";
    } else {
      keteranganEl.innerHTML = "Bagi yang BELUM LUNAS administrasi sekolah, segera dilunasi sebelum wasana warsa tanggal 14 Juni 2025 sebagai syarat pengambilan Surat Keterangan Lulus (SKL).";
    }

    kataMutiaraEl.innerHTML = "“Jadilah seperti padi, semakin berisi semakin merunduk.”";
  } else {
    hasilEl.style.display = "block";
    hasilStatusEl.innerHTML = "NISN tidak ditemukan!";
    keteranganEl.innerHTML = "";
    kataMutiaraEl.innerHTML = "";
  }
}
